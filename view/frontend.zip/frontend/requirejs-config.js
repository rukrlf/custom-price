var config = {
    config: {
        mixins: {
            'Magento_Catalog/js/price-box': {
                'Rukshan_CustomPrice/js/price-box-mixin': true
            }
        }
    }
};
