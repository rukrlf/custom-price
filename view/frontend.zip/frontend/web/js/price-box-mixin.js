define(['jquery'], function ($) {

    return function (widget) {

        // var customData = $.parseJSON(window.checkoutConfig.customData);

        //return customData;


        var globalOptions = {
            productId: null,
            priceConfig: null,
            prices: {},
            priceTemplate: '<span class="price"><%- data.formatted %></span>'
        };

        $.widget('mage.priceBox', widget, {
            options: globalOptions
        });
        return $.mage.priceBox;

    }
});
